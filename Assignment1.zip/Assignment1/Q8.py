# Predict the output :
# 
# x = input("Enter number")
# print(type(x))
# 
# The above print function will return the output string
# 
# Even if we enter number it accept default as a string in python  