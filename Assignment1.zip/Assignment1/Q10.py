# What will be the output : 
print("10" + "20")  # It will return 1020
print(10 + 20)  # It will return 30

# Explanation

# The first print statement will return value with concatination. It return string
# And the second print statement will return value with addition of two number. It return number
