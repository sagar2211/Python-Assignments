a = 10
b = 10
print(id(a) == id(b))

# Output = True
# Explanation
# Because the values are same and so that it uses same memory