# why does the input function always return a string in python
# => The input() function in Python always returns a string 
# because its primary purpose is to read text-based input from the user

# We can convert that string input to another type like below
# If we have to convert one of the string input to int then follow below steps:
data = int(input())