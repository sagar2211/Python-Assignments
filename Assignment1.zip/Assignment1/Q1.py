data = "Jay Ganesh..."

print("value of data is : ", data)

print("type of data is : ", type(data))

print("memory address of data is : ", id(data))
