# What does the id() return
# => It is returning the memory address of object

# Is the value returned by id() same for two variables holding the same values
# => Yes  =>  Because if the values are same then it will uses the same memory 