
def Display():
    print("Enter Name of User")
    Name = input()
    print("Enter Age")
    Age = int(input())
    print("User name is : ", Name, "and age is : ", Age)

def main():
    Display()

# Starter
if __name__ == "__main__":
    main()