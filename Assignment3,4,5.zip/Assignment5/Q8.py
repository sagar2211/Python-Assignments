# Explain why the following code works without declaration
x = 100
# Compare with this 'C' or 'Java'

# Explanation
# The above code will work because in python does not need to decalre value  like C or Java