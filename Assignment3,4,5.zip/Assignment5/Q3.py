# Predict the output:

def fun():
    x=10
    print(x)

fun()       # This is call the fun function and print the 10 value
print(x)    # This will return an error like below:
# NameError: name 'x' is not defined

