# What is the difference between :
# print()
# return

# print is use for print or display the value
# return is use for when we have to return response from function then we used return. It is not mandatory.
# The default return value is None
