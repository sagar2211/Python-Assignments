# What is Difference between :
x = 10
x = "Ten"

# Is this allowed? Why?
# => This is allowed because typecasting is allowed in Python