# What is difference between:
# Function with Parameter
# Function without Parameter

# Explanation:
# Function with Parameter: We should pass number of parameter which is same as argument in 
# function defination, If any default argument is there then while passing parameter 
# we can used it as optional

# unction without Parameter: We can call function without passing any parameter.