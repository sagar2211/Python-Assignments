# Predict the output
a=5
print(type(a))  # output: <class 'integer'>
a=5.5
print(type(a))  # output: <class 'float'>
a="Python"
print(type(a))  # output: <class 'str'>

# What python features does this demonstrates?
# This demonstrates we can reuse the same variable with different data types of values