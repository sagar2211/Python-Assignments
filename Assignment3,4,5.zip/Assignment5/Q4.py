# Write a function that does not return anything but prints a message.

def Display():
    print("Jay Ganesh...")

def main():
    Display()

# Starter
if __name__ == "__main__":
    main()

# Explain the default return value of such a function
# The display function prints a message but does not use the return keyword.
# So, Python automatically returns a special value called None.