# Explain how python manages memory automatically?
# Python manages memory automatically by using a combination of a private heap space, 
# a primary mechanism called reference counting, and a supplementary generational garbage collector