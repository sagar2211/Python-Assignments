# What is a set in Python?
# => A set is an unordered collection used to store unique element only, mainly for removing duplicates.
# Example
# s = {10,20,30,20} 