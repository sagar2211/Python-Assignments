# What is None in Python?
# =>None type represents the absense of a value and is commonly 
# used as a placeholder or default return value.

# Is it same as 0, false or empty string
# No, NoneType is not the same as 0, False, or an empty string (""). 