# Predict the output:
s = {10,20,30,10,20}
print(s)            # output : {10, 20, 30}

# Why are some values are missing?
# We used set to store value and the store is not allowing duplicate value it removes duplicate values
