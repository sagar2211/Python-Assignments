# Predict the output
x = None
print(type(x))      # output: <class 'NoneType'>
print(x == False)   # output: False

# Explain the result
# The line 3 is print the data type
# Line 4 is used for comparing value and it is false because the values are different
