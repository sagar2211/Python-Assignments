# What is dynamic typing in Python?
# In python you don't need to declare the type of variable while creating it,
# The type is automatically assigned during runtime based on the value assigned.
# You can even change the type of variable by assigning a new value of different type.