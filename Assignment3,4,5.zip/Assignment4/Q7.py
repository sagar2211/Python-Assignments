# What is the boolean data type in Python?
# => The bool data type represents truth values, mainly used in decision making and conditional statements.

# List all values that evaluates to False
# 0, False, 0.0, 0j, "", [], (), {}, set(), range(0)