# What is difference between bytes and bytearray?

# Mutability
# bytes : bytes are immutable
# bytearray" bytearray are mutable

# use cases
# bytes: Used in file handling and networking
# bytearray : Network programming and protocols