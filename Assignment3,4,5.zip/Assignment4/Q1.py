# What are bytes in Python?
# =>The bytes data type represents an immutable sequence of bytes, mostly used in 
# file handling and networking

# Example b= bytes([65,66,67])