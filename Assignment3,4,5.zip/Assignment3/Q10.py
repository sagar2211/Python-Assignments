# What is difference between :
range(1,10)
range(1,10,2)

# Explanation
# The line number 2 statement is working with default step 1. output : 1,2,3,4,5,6,7,8,9
# The line number 3 statement is working with step 2. output : 1,3,5,7,9
