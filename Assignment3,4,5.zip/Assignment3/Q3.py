# Predict the opt

lst = [10, 20,30]
tpl = (10,20,30)

lst[0] = 100
tpl[0] = 100

# Which will raise an error and why

# Then line number 7 will raise an error because there we try to modify the value of tuple
# And in tuple we can't do it