# Predict the output:
r = range(5)        
print(r)            # output: range(0, 5)
print(list(r))      # output: [0, 1, 2, 3, 4]