# Predict the output
d = { 1 : "One", 1 : "ONE", 2 : "Two"}

print(d)

#  output : {1: 'ONE', 2: 'Two'}

# why does this happen?
# =>It happen because dictionary does not allowed duplicate keys, And it accept only last key
