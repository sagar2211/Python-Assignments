# What is dictionary in Python?
# A dictionary store data in key-value pairs, making data retrival fast and efficient
# The key must be immutable because we refer key for access the value.
# Duplicates key are not allowed, because while accessing value from dictionary it will confused.
